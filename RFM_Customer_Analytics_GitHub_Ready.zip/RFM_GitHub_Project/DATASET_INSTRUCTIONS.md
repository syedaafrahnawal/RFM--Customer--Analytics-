# Dataset Instructions

The project uses the public **Olist Brazilian E-Commerce Public Dataset**.

For the main RFM analysis, only these three CSV files are required:

```text
olist_customers_dataset.csv
olist_orders_dataset.csv
olist_order_payments_dataset.csv
```

Place them in:

```text
data/raw/
```

The repository intentionally does not contain the raw CSV files. This keeps the GitHub repository smaller and avoids committing a large dataset.

The original dataset also contains other useful files (products, sellers, reviews, geolocation, etc.). They are not required for the current version of the project, but they can be used later for extensions.

After adding the files, run:

```bash
python src/pipeline.py
```

The pipeline will generate the processed data, saved models, evaluation results and figures.
