"""
Simple Streamlit dashboard for the RFM project.
Run from the project root:
    streamlit run dashboard/app.py
"""

from pathlib import Path
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
rfm_path = ROOT / "data" / "processed" / "rfm_customer_segments.csv"
profile_path = ROOT / "outputs" / "cluster_profile.csv"

st.set_page_config(page_title="RFM Customer Analytics", layout="wide")
st.title("RFM Customer Analytics Dashboard")
st.caption("BCA Final Year Project - Customer Segmentation using RFM and K-Means")

if not rfm_path.exists() or not profile_path.exists():
    st.error("Processed files are missing. Run `python src/pipeline.py` first.")
    st.stop()

rfm = pd.read_csv(rfm_path)
profile = pd.read_csv(profile_path)

c1, c2, c3 = st.columns(3)
c1.metric("Customers", f"{len(rfm):,}")
c2.metric("Avg. Monetary Value", f"{rfm['Monetary'].mean():.2f}")
c3.metric("Segments", f"{rfm['segment'].nunique()}")

st.subheader("Customer Segments")
st.dataframe(profile, use_container_width=True)

st.subheader("Segment Distribution")
st.bar_chart(profile.set_index("segment")["customer_count"])

st.subheader("Explore Customers")
segment = st.selectbox("Select a segment", ["All"] + sorted(rfm["segment"].dropna().unique().tolist()))
view = rfm if segment == "All" else rfm[rfm["segment"] == segment]
st.dataframe(view.head(500), use_container_width=True)
