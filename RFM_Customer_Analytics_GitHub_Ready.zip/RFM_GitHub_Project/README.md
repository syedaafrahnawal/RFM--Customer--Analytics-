# RFM-Based Customer Analytics and Customer Segmentation

This is my BCA final year project on **RFM (Recency, Frequency and Monetary) customer analysis** using the Olist Brazilian E-Commerce dataset.

The main idea is pretty simple: instead of treating every customer the same, we use their buying behaviour to group them into useful customer segments. I used machine learning clustering methods and then interpreted the groups from a business point of view.

## What the project does

- Loads and cleans the Olist order data
- Keeps completed/delivered orders for the main analysis
- Calculates:
  - **Recency** - how recently a customer purchased
  - **Frequency** - how many different orders they placed
  - **Monetary** - how much they spent
- Applies log transformation and standardization
- Compares:
  - K-Means
  - Hierarchical Agglomerative Clustering
  - Gaussian Mixture Model
- Uses Silhouette, Davies-Bouldin and Calinski-Harabasz scores for evaluation
- Builds a final 4-cluster K-Means model
- Creates charts and a simple Streamlit dashboard
- Includes the final report and viva questions

## Final customer segments

The final four groups are interpreted as:

1. **High-Value / Dormant** - customers who spent relatively more but have not purchased recently.
2. **Low-Value / Inactive** - mostly one-time customers with lower spending and high recency.
3. **Loyal / High-Value** - customers with more than one order and relatively high value.
4. **Recent / New** - customers who purchased recently but have not built a long purchase history yet.

These names are business interpretations, not labels given by the original dataset.

## Dataset

The raw Olist dataset is **not included in this GitHub repository** because it contains large CSV files and is better downloaded separately.

The project only needs these three files:

- `olist_customers_dataset.csv`
- `olist_orders_dataset.csv`
- `olist_order_payments_dataset.csv`

Download the public Olist Brazilian E-Commerce dataset and place those three files inside:

```text
data/raw/
```

The filenames should stay exactly the same.

See `DATASET_INSTRUCTIONS.md` for more details.

## How to run the project

### 1. Install Python

Python 3.10 or newer is recommended.

### 2. Install the libraries

```bash
pip install -r requirements.txt
```

### 3. Add the dataset

Put the three required Olist CSV files in `data/raw/`.

### 4. Run the analysis

From the project root:

```bash
python src/pipeline.py
```

This will create the processed RFM data, models, comparison results and figures.

### 5. Open the dashboard

```bash
streamlit run dashboard/app.py
```

The dashboard reads the processed RFM results and shows the customer segments.

## Project structure

```text
RFM_GitHub_Project/
├── data/
│   ├── raw/                  # Put downloaded CSV files here
│   └── processed/            # Generated/derived data
├── models/                   # Saved scaler and K-Means model
├── outputs/
│   ├── figures/              # Charts used in the project
│   ├── cluster_profile.csv
│   └── model_comparison.csv
├── src/
│   └── pipeline.py           # Main data + ML pipeline
├── dashboard/
│   └── app.py                # Streamlit dashboard
├── docs/
│   ├── RFM_Customer_Analytics_Final_Year_Report.docx
│   └── Viva_Questions_and_Answers.docx
├── DATASET_INSTRUCTIONS.md
├── requirements.txt
├── .gitignore
└── README.md
```

## Important note about the results

For practical computation, model comparison was done using a reproducible sample of 10,000 customers. The final K-Means model was then fitted on the complete RFM customer dataset.

I selected **4 clusters** even though a smaller number can sometimes give a better pure clustering score. The reason was that four groups gave a more useful and understandable business segmentation for this final-year project.

## Technologies used

- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Streamlit
- Jupyter/IDE of choice

## Project documents

The `docs` folder contains the editable final-year report and viva questions/answers.

The report intentionally leaves student/college details blank so they can be filled in before submission.

## Disclaimer

This is an academic project. The customer segments are based on the Olist public dataset and are meant to demonstrate data analytics and machine learning concepts.
