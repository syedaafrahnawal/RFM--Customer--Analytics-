This folder contains the final-year project report and viva preparation document. Fill in your personal/college details before submission.
