"""
RFM Customer Analytics - main pipeline

Put these three Olist files inside data/raw/:
- olist_customers_dataset.csv
- olist_orders_dataset.csv
- olist_order_payments_dataset.csv

Then run:
    python src/pipeline.py
"""

from pathlib import Path
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
FIGURES = ROOT / "outputs" / "figures"

for p in [PROCESSED, MODELS, FIGURES]:
    p.mkdir(parents=True, exist_ok=True)

def main():
    required = [
        RAW / "olist_customers_dataset.csv",
        RAW / "olist_orders_dataset.csv",
        RAW / "olist_order_payments_dataset.csv",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError(
            "Missing raw dataset files:\n" + "\n".join(missing) +
            "\n\nSee DATASET_INSTRUCTIONS.md for where to get the Olist dataset."
        )

    customers = pd.read_csv(required[0])
    orders = pd.read_csv(required[1])
    payments = pd.read_csv(required[2])

    orders["order_purchase_timestamp"] = pd.to_datetime(
        orders["order_purchase_timestamp"], errors="coerce"
    )
    orders["order_delivered_customer_date"] = pd.to_datetime(
        orders["order_delivered_customer_date"], errors="coerce"
    )

    delivered = orders[orders["order_status"] == "delivered"].copy()
    delivered = delivered.merge(
        customers[["customer_id", "customer_unique_id"]],
        on="customer_id",
        how="left"
    )
    payments_total = (
        payments.groupby("order_id", as_index=False)["payment_value"].sum()
        .rename(columns={"payment_value": "order_value"})
    )
    delivered = delivered.merge(payments_total, on="order_id", how="left")
    delivered["order_value"] = delivered["order_value"].fillna(0)

    reference_date = delivered["order_purchase_timestamp"].max() + pd.Timedelta(days=1)

    rfm = (
        delivered.groupby("customer_unique_id")
        .agg(
            Recency=("order_purchase_timestamp",
                     lambda x: (reference_date - x.max()).days),
            Frequency=("order_id", "nunique"),
            Monetary=("order_value", "sum")
        )
        .reset_index()
    )

    # Log transform reduces the effect of extreme monetary/frequency values.
    features = ["Recency", "Frequency", "Monetary"]
    X = np.log1p(rfm[features])
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    with open(MODELS / "rfm_scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)

    # Compare the three requested clustering approaches on a reproducible sample.
    sample_n = min(10000, len(rfm))
    sample_idx = rfm.sample(sample_n, random_state=42).index
    X_sample = X_scaled[rfm.index.isin(sample_idx)]

    rows = []
    for k in range(2, 9):
        km = KMeans(n_clusters=k, n_init=20, max_iter=500, random_state=42)
        labels = km.fit_predict(X_sample)
        rows.append({
            "model": "K-Means",
            "clusters": k,
            "silhouette": silhouette_score(X_sample, labels),
            "davies_bouldin": davies_bouldin_score(X_sample, labels),
            "calinski_harabasz": calinski_harabasz_score(X_sample, labels),
        })

    k = 4
    agg = AgglomerativeClustering(n_clusters=k)
    labels = agg.fit_predict(X_sample)
    rows.append({
        "model": "Hierarchical",
        "clusters": k,
        "silhouette": silhouette_score(X_sample, labels),
        "davies_bouldin": davies_bouldin_score(X_sample, labels),
        "calinski_harabasz": calinski_harabasz_score(X_sample, labels),
    })

    gmm = GaussianMixture(n_components=k, random_state=42, n_init=5)
    labels = gmm.fit_predict(X_sample)
    rows.append({
        "model": "Gaussian Mixture",
        "clusters": k,
        "silhouette": silhouette_score(X_sample, labels),
        "davies_bouldin": davies_bouldin_score(X_sample, labels),
        "calinski_harabasz": calinski_harabasz_score(X_sample, labels),
    })

    comparison = pd.DataFrame(rows)
    comparison.to_csv(ROOT / "outputs" / "model_comparison.csv", index=False)

    # Final four-cluster K-Means model.
    model = KMeans(n_clusters=4, n_init=20, max_iter=500, random_state=42)
    rfm["cluster"] = model.fit_predict(X_scaled)

    with open(MODELS / "kmeans_final.pkl", "wb") as f:
        pickle.dump(model, f)

    # Business-friendly labels based on the final cluster profiles.
    profiles = rfm.groupby("cluster")[features].mean()
    profiles["customer_count"] = rfm.groupby("cluster").size()
    profiles["percentage"] = profiles["customer_count"] / len(rfm) * 100

    # Assign labels by profile characteristics rather than relying on cluster numbers.
    labels_map = {}
    recent_cluster = profiles["Recency"].idxmin()
    labels_map[recent_cluster] = "Recent / New"

    remaining = [c for c in profiles.index if c != recent_cluster]
    loyal_cluster = profiles.loc[remaining, "Frequency"].idxmax()
    if profiles.loc[loyal_cluster, "Frequency"] > 1.2:
        labels_map[loyal_cluster] = "Loyal / High-Value"

    remaining = [c for c in remaining if c != loyal_cluster]
    if remaining:
        high_value = profiles.loc[remaining, "Monetary"].idxmax()
        labels_map[high_value] = "High-Value / Dormant"
        for c in remaining:
            if c != high_value:
                labels_map[c] = "Low-Value / Inactive"

    rfm["segment"] = rfm["cluster"].map(labels_map)
    rfm.to_csv(PROCESSED / "rfm_customer_segments.csv", index=False)
    delivered.to_csv(PROCESSED / "delivered_orders_base.csv", index=False)

    profile = (
        rfm.groupby(["cluster", "segment"])
        .agg(
            customer_count=("customer_unique_id", "count"),
            percentage=("customer_unique_id", lambda x: len(x) / len(rfm) * 100),
            avg_recency=("Recency", "mean"),
            avg_frequency=("Frequency", "mean"),
            avg_monetary=("Monetary", "mean"),
        )
        .reset_index()
    )
    profile.to_csv(ROOT / "outputs" / "cluster_profile.csv", index=False)

    # EDA plots
    plt.figure(figsize=(8, 5))
    rfm["Recency"].plot(kind="hist", bins=40)
    plt.title("Recency Distribution")
    plt.xlabel("Days")
    plt.tight_layout()
    plt.savefig(FIGURES / "01_recency_distribution.png", dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    rfm["Frequency"].plot(kind="hist", bins=30)
    plt.title("Frequency Distribution")
    plt.xlabel("Number of Orders")
    plt.tight_layout()
    plt.savefig(FIGURES / "02_frequency_distribution.png", dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    rfm["Monetary"].plot(kind="hist", bins=40)
    plt.title("Monetary Distribution")
    plt.xlabel("Payment Value")
    plt.tight_layout()
    plt.savefig(FIGURES / "03_monetary_distribution.png", dpi=150)
    plt.close()

    # Silhouette comparison for K-Means.
    km_rows = comparison[comparison["model"] == "K-Means"]
    plt.figure(figsize=(8, 5))
    plt.plot(km_rows["clusters"], km_rows["silhouette"], marker="o")
    plt.title("K-Means Silhouette Score by Number of Clusters")
    plt.xlabel("Number of Clusters")
    plt.ylabel("Silhouette Score")
    plt.xticks(range(2, 9))
    plt.tight_layout()
    plt.savefig(FIGURES / "04_kmeans_silhouette.png", dpi=150)
    plt.close()

    pca = PCA(n_components=2, random_state=42)
    X_pca = pca.fit_transform(X_scaled)
    plt.figure(figsize=(8, 6))
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=rfm["cluster"], s=5, alpha=0.5)
    plt.title("Customer Segments in PCA Space")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.tight_layout()
    plt.savefig(FIGURES / "05_cluster_pca.png", dpi=150)
    plt.close()

    plt.figure(figsize=(9, 5))
    profile.sort_values("customer_count").plot(
        x="segment", y="customer_count", kind="bar", legend=False
    )
    plt.title("Customer Segment Sizes")
    plt.xlabel("Segment")
    plt.ylabel("Customers")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(FIGURES / "06_segment_sizes.png", dpi=150)
    plt.close()

    print("Pipeline completed.")
    print(f"Customers analysed: {len(rfm):,}")
    print(f"Reference date: {reference_date.date()}")
    print(profile.to_string(index=False))

if __name__ == "__main__":
    main()
